

import time
import bisect

# 1. HASH TABLE SEARCH
def hash_search(table, key):
    return table.get(key), 1


# 2. ITERATIVE BINARY SEARCH
def binary_search(arr, key):
    low = 0
    high = len(arr) - 1
    comparisons = 0

    while low <= high:
        mid = (low + high) // 2
        comparisons += 1

        if arr[mid] == key:
            return arr[mid], comparisons
        elif key < arr[mid]:
            high = mid - 1
        else:
            low = mid + 1

    return None, comparisons


# 3. RECURSIVE B-TREE-STYLE SEARCH
NODE_SIZE = 128

def build_btree(arr):
    level = []

    for i in range(0, len(arr), NODE_SIZE):
        keys = arr[i:i + NODE_SIZE]
        level.append({
            "keys": keys,
            "children": [],
            "maximum": keys[-1]
        })

    while len(level) > 1:
        next_level = []

        for i in range(0, len(level), NODE_SIZE):
            children = level[i:i + NODE_SIZE]
            next_level.append({
                "keys": [],
                "children": children,
                "maximum": children[-1]["maximum"]
            })

        level = next_level

    return level[0]


def recursive_btree_search(node, key):
    if node is None:
        return None, 0

    comparisons = 0

    if not node["children"]:
        pos = bisect.bisect_left(node["keys"], key)
        comparisons += 1

        if pos < len(node["keys"]) and node["keys"][pos] == key:
            return node["keys"][pos], comparisons

        return None, comparisons

    maximums = [child["maximum"] for child in node["children"]]
    pos = bisect.bisect_left(maximums, key)
    comparisons += 1

    if pos == len(node["children"]):
        return None, comparisons

    result, child_comparisons = recursive_btree_search(
        node["children"][pos], key
    )

    return result, comparisons + child_comparisons


# PERFORMANCE TESTING
def test_search(name, function, index, key):
    start = time.perf_counter()
    result, comparisons = function(index, key)
    elapsed = (time.perf_counter() - start) * 1000

    status = "FOUND" if result is not None else "NOT FOUND"

    print(
        f"{name:<18} {status:<10} "
        f"{comparisons:<12} {elapsed:.6f} ms"
    )


def main():
    sizes = [1000, 10000, 100000, 1000000]

    print("STUDENT RECORD SEARCH SYSTEM")

    for n in sizes:
        print("\nDataset size:", n)
        print("-" * 65)
        print(f"{'Algorithm':<18} {'Result':<10} "
              f"{'Comparisons':<12} Execution Time")

        records = list(range(1001, 1001 + n))

        # Preprocessing
        hash_table = {key: key for key in records}
        sorted_records = sorted(records)
        btree = build_btree(sorted_records)

        # Search for an existing registration number
        key = records[n // 2]

        test_search("Hash Search", hash_search, hash_table, key)
        test_search("Binary Search", binary_search, sorted_records, key)
        test_search("B-Tree Search", recursive_btree_search, btree, key)

        # Test an absent registration number
        missing_key = -1

        assert hash_search(hash_table, missing_key)[0] is None
        assert binary_search(sorted_records, missing_key)[0] is None
        assert recursive_btree_search(btree, missing_key)[0] is None

        assert hash_search(hash_table, key)[0] == key
        assert binary_search(sorted_records, key)[0] == key
        assert recursive_btree_search(btree, key)[0] == key

        print("Existing and missing key tests: PASSED")


if __name__ == "__main__":
    main()
